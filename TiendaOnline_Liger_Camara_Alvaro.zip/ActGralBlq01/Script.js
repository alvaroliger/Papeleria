// Lista de productos
const productos = [
  { nombre: "Cuaderno de cuadros 80 páginas", precio: 7, imagen: "images/cuaderno.jpg", categoria: "Cuadernos" },
  { nombre: "Pack escolar completo", precio: 90, imagen: "images/pack_escolar.jpg", categoria: "Packs" },
  { nombre: "Bolígrafo borrable", precio: 2, imagen: "images/boligrafo_borrable.jpg", categoria: "Escritura" },
  { nombre: "Regla de 30 cm", precio: 3, imagen: "images/regla.jpg", categoria: "Instrumentos" },
  { nombre: "Calculadora científica", precio: 50, imagen: "images/calculadora.jpg", categoria: "Electrónica" },
  { nombre: "Juego de marcadores", precio: 15, imagen: "images/marcadores.jpg", categoria: "Colores" },
  { nombre: "Pinturas acuarelables", precio: 12, imagen: "images/pinturas.jpg", categoria: "Colores" },
  { nombre: "Agenda escolar 2024", precio: 20, imagen: "images/agenda.jpg", categoria: "Oficina" },
  { nombre: "Globo terráqueo miniatura", precio: 30, imagen: "images/globo.jpg", categoria: "Decoración" },
  { nombre: "Carpeta de anillas", precio: 8, imagen: "images/carpeta_anillas.jpg", categoria: "Archivo" },
  { nombre: "Estuche escolar", precio: 10, imagen: "images/estuche.jpg", categoria: "Accesorios" },
  { nombre: "Rotuladores permanentes", precio: 5, imagen: "images/rotuladores.jpg", categoria: "Colores" },
  { nombre: "Tijeras escolares", precio: 4, imagen: "images/tijeras.jpg", categoria: "Instrumentos" },
  { nombre: "Pegamento en barra", precio: 2, imagen: "images/pegamento.jpg", categoria: "Adhesivos" },
  { nombre: "Papel fotocopiadora A4", precio: 6, imagen: "images/papel.jpg", categoria: "Papel" },
  { nombre: "Mochila escolar", precio: 25, imagen: "images/mochila.jpg", categoria: "Accesorios" },
  { nombre: "Goma de borrar", precio: 1, imagen: "images/goma.jpg", categoria: "Escritura" },
  { nombre: "Sacapuntas manual", precio: 2, imagen: "images/sacapuntas.jpg", categoria: "Escritura" },
  { nombre: "Cinta correctora", precio: 3, imagen: "images/corrector.jpg", categoria: "Accesorios" },
  { nombre: "Bloc de notas adhesivas", precio: 4, imagen: "images/notas.jpg", categoria: "Oficina" },
  { nombre: "Caja de clips", precio: 3, imagen: "images/clips.jpg", categoria: "Oficina" },
  { nombre: "Grapadora de escritorio", precio: 15, imagen: "images/engrapadora.jpg", categoria: "Archivo" },
  { nombre: "Cinta adhesiva transparente", precio: 2, imagen: "images/cinta_adhesiva.jpg", categoria: "Adhesivos" },
  { nombre: "Plastilina escolar", precio: 5, imagen: "images/plastilina.jpg", categoria: "Manualidades" },
  { nombre: "Carpeta clasificadora", precio: 12, imagen: "images/clasificadora.jpg", categoria: "Archivo" },
  { nombre: "Rotuladores fluorescentes", precio: 6, imagen: "images/fluorescentes.jpg", categoria: "Colores" },
  { nombre: "Bolsa de papel para regalos", precio: 3, imagen: "images/bolsa_regalos.jpg", categoria: "Decoración" },
  { nombre: "Set de geometría", precio: 10, imagen: "images/geometria.jpg", categoria: "Instrumentos" },
  { nombre: "Caja de alfileres", precio: 4, imagen: "images/alfileres.jpg", categoria: "Costura" },
];

// Variables para el carrito
let carrito = [];
let total = 0;
const presupuesto = 1000; 

// Renderiza los productos en la página
function renderizarProductos() {
  const listaProductos = document.getElementById("lista-productos");
  listaProductos.innerHTML = productos
    .map(
      (producto, indice) => `
      <div class="producto" data-indice="${indice}">
        <img src="${producto.imagen}" alt="${producto.nombre}">
        <h3>${producto.nombre}</h3>
        <p>€${producto.precio}</p>
        <button onclick="agregarAlCarrito('${producto.nombre}', ${producto.precio})">Agregar</button>
      </div>`
    )
    .join("");
}

// Añade un producto al carrito
function agregarAlCarrito(nombre, precio) {
  if (total + precio > presupuesto) {
    alert(`No puedes añadir "${nombre}" al carrito. Excedes el presupuesto de €${presupuesto}.`);
    return;
  }
  carrito.push({ nombre, precio });
  total += precio;
  actualizarCarrito();
}

// Actualiza la vista del carrito y calcula el total
function actualizarCarrito() {
  const itemsCarrito = document.getElementById("items-carrito");
  const contadorCarrito = document.getElementById("contador-carrito");
  itemsCarrito.innerHTML = "";
  carrito.forEach((item, indice) => {
    const itemDiv = document.createElement("div");
    itemDiv.innerHTML = `${item.nombre} - €${item.precio} <span class='boton-quitar' onclick="eliminarDelCarrito(${indice})">&times;</span>`;
    itemsCarrito.appendChild(itemDiv);
  });
  document.getElementById("total").textContent = `Total: €${total}`;
  contadorCarrito.textContent = carrito.length;
}

// Elimina un producto del carrito
function eliminarDelCarrito(indice) {
  total -= carrito[indice].precio;
  carrito.splice(indice, 1);
  actualizarCarrito();
}

// Vacía el carrito
function vaciarCarrito() {
  carrito = [];
  total = 0;
  actualizarCarrito();
}

// Muestra/oculta el carrito
function alternarCarrito() {
  const seccionCarrito = document.getElementById("carrito");
  if (seccionCarrito.classList.contains("oculto")) {
    seccionCarrito.classList.remove("oculto");
  } else {
    seccionCarrito.classList.add("oculto");
  }
}

// Filtra los productos de la búsqueda
function filtrarProductos() {
  const busqueda = document.getElementById("busqueda").value.toLowerCase();
  document.querySelectorAll(".producto").forEach((producto) => {
    const nombre = producto.querySelector("h3").textContent.toLowerCase();
    producto.style.display = nombre.includes(busqueda) ? "block" : "none";
  });
}

// Finaliza la compra y vacía el carrito si hay confirmación
function finalizarCompra() {
  if (carrito.length === 0) {
    alert("Tu carrito está vacío.");
    return;
  }
  const confirmarCompra = confirm(`¿Seguro que quieres comprar estos artículos por €${total}?`);
  if (confirmarCompra) {
    alert(`¡Gracias por tu compra! Total a pagar: €${total}`);
    vaciarCarrito();
  }
}

// Renderización de productos
renderizarProductos();